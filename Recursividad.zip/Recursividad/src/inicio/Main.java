package inicio;


import logica.RecursividadRepaso;

public class Main {
    public static void main(String[] args) {
        RecursividadRepaso r = new RecursividadRepaso();
        // r.contarDiez(1);
        //r.factorial(7);
        // System.out.println("El factorial es: "+r.factorial(7));
        //int [] array = {1,2,3,4,5};
        //int indice2 =  r.buscarNumero(array,0 ,6);
        //System.out.println("El numero se encuentra en la posicion: "+indice2);
        //int digi = r.contarDigitos(123456);
        //System.out.println("El numero tiene: "+digi+" digitos");
        //int suma = r.sumarPotencias(2,4);
        //System.out.println("La suma de las potencias es: "+suma);
        //String word = r.invertirPalabra("");
        //System.out.println("La palabra invertida es: "+ word);
        //int [] array1 = {1,2,3};
        //int [] array2 = {1,2,3};
        //int indice = 0;
        //boolean answer = r.validarArreglos(array1,array2,indice);
        //System.out.println("Los arreglos son iguales?: "+answer);
        int[][] matriz = {
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}
        };
        int fila = 0;
        int columna = 0;
        r.recorrerMatriz(matriz, fila, columna);




    }

    }
